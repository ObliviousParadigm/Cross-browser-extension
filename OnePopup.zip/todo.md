# OnePopup

* ~~Open the tab when the user clicks on it~~
* ~~Sort and split the tabs based on the window ID~~
* Beautify the extension
  * ~~Use bootstrap~~
  * ~~Fix title~~
  * ~~Highlight active tab~~
  * ~~Remove underline~~
  * ~~Change colour~~
  * ~~Add padding/margins~~
* Make a variant that displays all the tabs from specific websites in one place
* Dark mode?
