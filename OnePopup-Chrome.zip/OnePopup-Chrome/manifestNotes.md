# Random notes on manifest.json file

## "browser_action"

* It contains the files that will be used to display a button attached to the Firefox toolbar

